package util;

/**
 * Created by acer on 2018/6/7.
 */


public class BusinessException extends BaseException {
    public BusinessException(String msg){
        super(msg);
    }
}
