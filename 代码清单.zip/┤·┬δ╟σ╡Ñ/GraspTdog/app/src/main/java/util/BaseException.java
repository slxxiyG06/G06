package util;

/**
 * Created by acer on 2018/6/7.
 */

public class BaseException  extends Exception {
    public BaseException(String msg){
        super(msg);
    }
}
