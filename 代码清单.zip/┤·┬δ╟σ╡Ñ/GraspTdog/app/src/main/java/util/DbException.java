package util;

/**
 * Created by acer on 2018/6/7.
 */


public class DbException extends BaseException {
    public DbException(java.lang.Throwable ex){
        super("出错"+ex.getMessage());
    }
}
