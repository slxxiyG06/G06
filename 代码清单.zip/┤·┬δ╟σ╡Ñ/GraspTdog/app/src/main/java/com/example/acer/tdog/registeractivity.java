package com.example.acer.tdog;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import cn.bmob.v3.BmobSMS;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.LogInListener;
import cn.bmob.v3.listener.QueryListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast.*;
import android.widget.Toast;

import com.bmob.mdoel.GdogSystemUser;
import com.bmob.mdoel.Gdog_search;
import com.google.gson.Gson;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.BmobObject;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import static android.widget.Toast.makeText;
import control.LoginActivity;

import control.SignUpActivity;

public class registeractivity extends loadingmian {
    private TextView etUsername;
    private TextView etPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
// TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.register);

        etUsername = (TextView) findViewById(R.id.etUsername);
        etPassword = (TextView) findViewById(R.id.etPassword);
        Button 注册 = (Button) findViewById(R.id.注册);
        Button 返回 = (Button) findViewById(R.id.返回);
        返回.setOnClickListener(new View.OnClickListener(){
                                  @Override
                                  public void onClick(View v){
                                      Intent intent = new Intent(registeractivity.this,loadingmian.class);
                                      startActivity(intent);
                                  }
                              }
        );
        注册.setOnClickListener(new View.OnClickListener(){
                                    @Override
                                    public void onClick(View v) {

                                        // 获取用户输入的用户名和密码
                                        String username = etUsername.getText().toString();
                                        String password = etPassword.getText().toString();

                                        // 非空验证
                                        if(TextUtils.isEmpty(username) || TextUtils.isEmpty(password)){
                                            Toast.makeText(registeractivity.this, "账号密码不能为空！", Toast.LENGTH_SHORT).show();
                                            return;
                                        }

                                        GdogSystemUser user = new GdogSystemUser();

                                        user.setUsername(username);
                                        user.setPassword(password);
                                        user.setRemovedate(false);
                                        user.signUp(new SaveListener<GdogSystemUser>() {
                                            @Override
                                            public void done(GdogSystemUser s, BmobException e) {
                                                if(e==null){
                                                    Toast.makeText(registeractivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                                                    registeractivity.this.finish();
                                                }else{
//loge(e)
                                                    Toast.makeText(registeractivity.this, "注册失败", Toast.LENGTH_SHORT).show();
                                                }
                                            }

                                        });
                                    }
        });
    }


}
