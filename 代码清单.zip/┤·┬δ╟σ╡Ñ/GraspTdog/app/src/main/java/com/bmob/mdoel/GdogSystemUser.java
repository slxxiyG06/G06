package com.bmob.mdoel;
import cn.bmob.v3.BmobObject;
import cn.bmob.v3.BmobUser;
/**
 * Created by acer on 2018/6/7.
 */
import java.util.Date;

public class GdogSystemUser extends BmobUser{
    private String userid;

    private String pwd;
    private Boolean removedate;

    public String getUserid() {
        return userid;
    }
    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPwd() {
        return pwd;
    }
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public Boolean getRemovedate() {
        return removedate;
    }
    public void setRemovedate(Boolean removedate) {
        this.removedate = removedate;
    }
}
