package com.example.acer.tdog;

import android.os.Bundle;
import android.content.Intent;
import cn.bmob.v3.Bmob;
import control.LoginActivity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import com.example.acer.tdog.R;
import android.widget.Button;

import android.view.Menu;
import android.os.Bundle;

public class buyactivity extends resultactivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
// TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.buy);
        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener(){
                                       @Override
                                       public void onClick(View v){
                                           Intent intent = new Intent(buyactivity.this,resultactivity.class);
                                           startActivity(intent);
                                           finish();
                                       }
                                   }
        );
    }
}
