package com.bmob.mdoel;
import java.util.Date;
import cn.bmob.v3.BmobObject;
import cn.bmob.v3.BmobUser;

import android.app.Activity;
import android.os.Bundle;
/**
 * Created by acer on 2018/6/7.
 */

public class Gdog_search extends BmobUser{
    private static String petid;
    private String all;
    private String image;
    private String rg;
    private String sha;
    private String eye;
    private String eyes;
    private String mou;
    private String belc;
    private String bodc;
    private String pac;
    private int price;
    private String gen;
//    private static String objectId;
//    private Date createdAt;
    public String getAll() {
        return all;
    }
    public void setAll(String all) {
        this.all = all;
    }

//    public Date getCreatedAt() {
//        return createdAt;
//    }
//    public void setCreatedAt(Date createdAt) {
//        this.createdAt = createdAt;
//    }

    public static String getPetid() {
        return petid;
    }
    public void setPetid(String petid) {
        this.petid = petid;
    }
    public String getImage(String s) {
        return image;
    }

//    public static String getObjectId() {
//        return objectId;
//    }
//    public void setObjectId(String objectId) {
//        this.objectId = objectId;
//    }
//
    public void setImage(String image) {
        this.image = image;
    }
    public String getRg(String s) {
        return rg;
    }
    public void setRg(String rg) {
        this.rg = rg;
    }
    public String getSha(String s) {
        return sha;
    }
    public void setSha(String sha) {
        this.sha = sha;
    }
    public String getEye(String s) {
        return eye;
    }
    public void setEye(String eye) {
        this.eye = eye;
    }
    public String getEyes(String s) {
        return eyes;
    }
    public void setEyes(String eyes) {
        this.eyes = eyes;
    }
    public String getMou(String s) {
        return mou;
    }
    public void setMou(String mou) {
        this.mou = mou;
    }
    public String getBelc() {
        return belc;
    }
    public void setBelc(String belc) {
        this.belc = belc;
    }
    public String getBodc() {
        return bodc;
    }
    public void setBodc(String bodc) {
        this.bodc = bodc;
    }
    public String getPac() {
        return pac;
    }
    public void setPac(String pac) {
        this.pac = pac;
    }
    public int getPrice(int i) {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    public String getGen(String s) {
        return gen;
    }
    public void setGen(String gen) {
        this.gen = gen;
    }

}
