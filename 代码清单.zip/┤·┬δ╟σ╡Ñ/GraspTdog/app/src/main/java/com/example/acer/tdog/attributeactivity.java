package com.example.acer.tdog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import com.example.acer.tdog.R;

import android.widget.AdapterView;
import android.widget.Button;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import android.content.Intent;
import android.widget.Spinner;
import android.widget.Toast;

public class attributeactivity extends inquiryactivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
// TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.attribute);
        Button fanhui = (Button) findViewById(R.id.fanhui);
        fanhui.setOnClickListener(new View.OnClickListener(){
                                      @Override
                                      public void onClick(View v){
                                          Intent intent = new Intent(attributeactivity.this,inquiryactivity.class);
                                          startActivity(intent);
                                          finish();
                                      }
                                  }
        );
        Spinner spinner1 = (Spinner) findViewById(R.id.tixingxialakuang);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 体型 = getResources().getStringArray(R.array.体型);
                Toast.makeText(attributeactivity.this, "体型:"+体型[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner2 = (Spinner) findViewById(R.id.huawenxialakuang);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 花纹 = getResources().getStringArray(R.array.花纹);
                Toast.makeText(attributeactivity.this, "花纹:"+花纹[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner3 = (Spinner) findViewById(R.id.yanjingxialakuang);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 眼睛 = getResources().getStringArray(R.array.眼睛);
                Toast.makeText(attributeactivity.this, "眼睛:"+眼睛[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner4= (Spinner) findViewById(R.id.yanjingsexialakuang);
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 眼睛色 = getResources().getStringArray(R.array.眼睛色);
                Toast.makeText(attributeactivity.this, "眼睛色:"+眼睛色[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner5 = (Spinner) findViewById(R.id.zuibaxialakuang);
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 嘴巴 = getResources().getStringArray(R.array.嘴巴);
                Toast.makeText(attributeactivity.this, "嘴巴:"+嘴巴[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner6 = (Spinner) findViewById(R.id.dupisexialakuang);
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 肚皮色 = getResources().getStringArray(R.array.肚皮色);
                Toast.makeText(attributeactivity.this, "肚皮色:"+肚皮色[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner7 = (Spinner) findViewById(R.id.shentisexialakuang);
        spinner7.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 身体色 = getResources().getStringArray(R.array.身体色);
                Toast.makeText(attributeactivity.this, "身体色:"+身体色[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner8 = (Spinner) findViewById(R.id.huawensexialakuang);
        spinner8.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 花纹色 = getResources().getStringArray(R.array.花纹色);
                Toast.makeText(attributeactivity.this, "花纹色:"+花纹色[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
    }
}
