package com.bmob.mdoel;
import cn.bmob.v3.BmobObject;
/**
 * Created by acer on 2018/6/7.
 */

public class Gdog_search_number extends BmobObject{
    private String attribute;
    private int numberOFtimes;

    public String getAttribute() {
        return attribute;
    }
    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }
    public int getNumberOFtimes() {
        return numberOFtimes;
    }
    public void setNumberOFtimes(int numberOFtimes) {
        this.numberOFtimes = numberOFtimes;
    }
}
