package com.example.acer.tdog;
import android.content.Intent;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import control.LoginActivity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.bmob.mdoel.Gdog_search;
import com.example.acer.tdog.R;

import android.widget.ArrayAdapter;
import android.widget.Button;

import android.view.Menu;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        //提供以下两种方式进行初始化操作：

        //第一：默认初始化
        Bmob.initialize(this, "16c69006fbc13bfc2e302a068a7ac37e");
        final Intent it = new Intent(this, loadingmian.class); //你要转向的Activity
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                startActivity(it); //执行
            }
        };
        timer.schedule(task, 1000);

//        Gdog_search dog = new Gdog_search();
////注意：不能调用gameScore.setObjectId("")方法
//        dog.setPetid("比目");
//        dog.setBelc("");
//        dog.setBodc("");
//        dog.getEye("");
//        dog.getEyes("");
//        dog.getGen("");
//        dog.getImage("");
//        dog.getMou("");
//        dog.getPrice(12);
//        dog.getRg("");
//        dog.getSha("");
//        dog.save(new SaveListener<String>() {
//
//            @Override
//            public void done(String objectId, BmobException e) {
//                if(e==null){
//                    Toast.makeText(MainActivity.this, "添加成功,",Toast.LENGTH_SHORT).show();
//                }else{
//                    Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
//                }
//            }
//        });

        // 注:自v3.5.2开始，数据sdk内部缝合了统计sdk，开发者无需额外集成，传渠道参数即可，不传默认没开启数据统计功能
        //Bmob.initialize(this, "Your Application ID","bmob");

        //第二：自v3.4.7版本开始,设置BmobConfig,允许设置请求超时时间、文件分片上传时每片的大小、文件的过期时间(单位为秒)，
        //BmobConfig config =new BmobConfig.Builder(this)
        ////设置appkey
        //.setApplicationId("Your Application ID")
        ////请求超时时间（单位为秒）：默认15s
        //.setConnectTimeout(30)
        ////文件分片上传时每片的大小（单位字节），默认512*1024
        //.setUploadBlockSize(1024*1024)
        ////文件的过期时间(单位为秒)：默认1800s
        //.setFileExpiration(2500)
        //.build();
        //Bmob.initialize(config);
    }
}

