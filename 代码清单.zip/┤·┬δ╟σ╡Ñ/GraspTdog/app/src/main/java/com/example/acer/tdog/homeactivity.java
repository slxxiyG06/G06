package com.example.acer.tdog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import com.example.acer.tdog.R;
import android.widget.Button;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import android.content.Intent;

public class homeactivity extends loadingmian {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
// TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.home);
        Button chaxun = (Button) findViewById(R.id.chaxun);
        chaxun.setOnClickListener(new View.OnClickListener(){
                                  @Override
                                  public void onClick(View v){
                                      Intent intent = new Intent(homeactivity.this,inquiryactivity.class);
                                      startActivity(intent);
                                      finish();
                                  }
                              }
        );
        Button tuichudenglu = (Button) findViewById(R.id.tuichudenglu);
        tuichudenglu.setOnClickListener(new View.OnClickListener(){
                                      @Override
                                      public void onClick(View v){
                                         Intent intent = new Intent(homeactivity.this,loadingmian.class);
                                          startActivity(intent);
                                          finish();
                                      }
                                  }
        );
    }
}