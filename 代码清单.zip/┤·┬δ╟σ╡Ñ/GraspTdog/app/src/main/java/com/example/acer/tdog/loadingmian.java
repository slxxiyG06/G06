package com.example.acer.tdog;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bmob.mdoel.GdogSystemUser;
import com.bmob.mdoel.Gdog_search;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import control.LoginActivity;

import static android.widget.Toast.makeText;

/**
 * Created by acer on 2018/6/7.
 */

public class loadingmian extends AppCompatActivity {
    private TextView etUsername;
    private TextView etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);
        etUsername = (TextView) findViewById(R.id.etUsername);
        etPassword = (TextView) findViewById(R.id.etPassword);

        Button 注册 = (Button) findViewById(R.id.注册);
        Button 登陆 = (Button) findViewById(R.id.登陆);
        登陆.setOnClickListener(new View.OnClickListener(){
                                  @Override
                                  public void onClick(View v){


                                      String username = etUsername.getText().toString();
                                      String password = etPassword.getText().toString();

                                      if(TextUtils.isEmpty(username) || TextUtils.isEmpty(password)){
                                          makeText(loadingmian.this, "用户名或密码不能为空", Toast.LENGTH_SHORT).show();
                                      }

//                                      // 使用BmobSDK提供的登录功能
//                                      Gdog_search dog = new Gdog_search();
////注意：不能调用gameScore.setObjectId("")方法
//                                      dog.setPetid("比目");
//                                      dog.setBelc(" ");
//                                      dog.setBodc(" ");
//                                      dog.getEye(" ");
//                                      dog.getEyes(" ");
//                                      dog.getGen(" ");
//                                      dog.getImage(" ");
//                                      dog.getMou(" ");
//                                      dog.getPrice(12);
//                                      dog.getRg(" ");
//                                      dog.getSha(" ");
//                                      Log.v("d d","d d");
//                                      dog.save(new SaveListener<String>() {
//
//                                          @Override
//                                          public void done(String objectId, BmobException e) {
//                                              if(e==null){
//                                                  Toast.makeText(loadingmian.this, "添加成功,",Toast.LENGTH_SHORT).show();
//                                              }else{
//                                                  Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
//                                              }
//                                          }
//                                      });
                                      GdogSystemUser user = new GdogSystemUser();
                                      user.setUsername(username);
                                      user.setPassword(password);
                                      user.login(new SaveListener<BmobUser>() {
                                          @Override
                                          public void done(BmobUser bmobUser, BmobException e) {
                                              if (e == null) {
                                                  makeText(loadingmian.this, "登陆成功", Toast.LENGTH_SHORT).show();
                                                  Intent intent = new Intent(loadingmian.this,homeactivity.class);
                                                  startActivity(intent);
                                                  finish();
                                              } else {
                                                  makeText(loadingmian.this, "登陆失败", Toast.LENGTH_SHORT).show();
                                              }
                                          }
                                      });
                                  }
                              });

        注册.setOnClickListener(new View.OnClickListener(){
                                             @Override
                                             public void onClick(View v){
                                                 Intent intent = new Intent(loadingmian.this,registeractivity.class);
                                                 startActivity(intent);
                                                 finish();
                                             }
                                         }
        );
    }

    public void verifyUserInfo(String username, String password) {
        // 获取用户输入的用户名和密码
        // 非空验证
    }
}
