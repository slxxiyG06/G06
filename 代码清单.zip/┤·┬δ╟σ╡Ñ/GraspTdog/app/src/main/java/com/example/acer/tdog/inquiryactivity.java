package com.example.acer.tdog;

import android.content.Intent;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.bmob.mdoel.Gdog_search;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class inquiryactivity extends homeactivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
// TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.inquiry);
        Spinner spinner = (Spinner) findViewById(R.id.spinner2);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 稀有度 = getResources().getStringArray(R.array.稀有度);
                Toast.makeText(inquiryactivity.this, "稀有度:"+稀有度[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Spinner spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                String[] 价格 = getResources().getStringArray(R.array.价格);
                Toast.makeText(inquiryactivity.this, "价格:"+价格[pos],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });
        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener(){
                                      @Override
                                      public void onClick(View v){
                                          Intent intent = new Intent(inquiryactivity.this,attributeactivity.class);
                                          startActivity(intent);
                                          finish();
                                      }
                                  }
        );
        Button button3= (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener(){
                                  @Override
                                  public void onClick(View v){
                                      Intent intent = new Intent(inquiryactivity.this,homeactivity.class);
                                      startActivity(intent);
                                      finish();
                                  }
                              }
        );
        Button button= (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){
                                       @Override
                                       public void onClick(View v){
//                                           cn.bmob.v3.BmobQuery<Gdog_search> query = new cn.bmob.v3.BmobQuery<Gdog_search>();
//                                           //查询playerName叫“比目”的数据
//
//                                           //返回50条数据，如果不加上这条语句，默认返回10条数据
//
//                                           //执行查询方法\
//                                           query.addWhereEqualTo("rg", "比目");
//                                           query.addWhereEqualTo("sha", "比目");
//                                           query.addWhereEqualTo("eye", "比目");
//                                           query.addWhereEqualTo("eyes", "比目");
//                                           query.addWhereEqualTo("mou", "比目");
//                                           query.addWhereEqualTo("belc", "比目");
//                                           query.addWhereEqualTo("bolc", "比目");
//                                           query.addWhereEqualTo("pac", "比目");
//                                           query.addWhereEqualTo("gen", "比目");
//                                           query.addWhereLessThan("price", 50);
//
//                                           query.setLimit(50);
//                                           query.findObjects(new FindListener<Gdog_search>() {
//                                              @Override
//
//
//                                               public void done(List<Gdog_search> object, BmobException e) {
//                                                   if(e==null){
//                                                       Toast.makeText(inquiryactivity.this, "查询成功：共"+object.size()+"条数据。", Toast.LENGTH_SHORT).show();
                                                       Intent intent = new Intent(inquiryactivity.this,resultactivity.class);
                                                       startActivity(intent);
                                                       finish();
//                                                       for ( Gdog_search search: object) {
//                                                          //获得playerName的信息
//                                                           search.getPetid();
//                                                           //获得数据的objectId信息z
//                                                           search.getObjectId();
//                                                           //获得createdAt数据创建时间（注意是：createdAt，不是createAt）
//                                                           search.getCreatedAt();
//                                                       }
//                                                   }else{
//                                                       Log.i("bmob","失败："+e.getMessage()+","+e.getErrorCode());
//                                                  }
//                                               }
//                                           });

                                       }
                                   }
        );
    }
}