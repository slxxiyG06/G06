package control;
import com.example.acer.tdog.R;

import cn.bmob.v3.exception.BmobException;

import java.lang.String;
import cn.bmob.v3.BmobUser;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import cn.bmob.v3.listener.SaveListener;

/**
 * Created by acer on 2018/6/7.
 */

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    EditText etUsername,etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);

        // 获取界面中的相关View
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        btnLogin = (Button) findViewById(R.id.登陆);
        // 设置登录按钮点击事件
        btnLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // 获取用户输入的用户名和密码
        String username = etUsername.getText().toString();
        String password = etPassword.getText().toString();

        // 非空验证
        if(TextUtils.isEmpty(username) || TextUtils.isEmpty(password)){
            Toast.makeText(this, "用户名或密码不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        // 使用BmobSDK提供的登录功能
        BmobUser user = new BmobUser();
        user.setUsername(username);
        user.setPassword(password);
        user.login(new SaveListener<String>() {

        @Override
        public void done(String s, BmobException e) {
            if (e == null) {
                Toast.makeText(LoginActivity.this, "登陆成功", Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(LoginActivity.this, "登陆失败", Toast.LENGTH_SHORT).show();
            }
        }
    });
    }
}